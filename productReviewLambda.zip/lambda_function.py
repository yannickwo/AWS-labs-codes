import sys
import json
import pymysql
import pymysql.cursors
import boto3
from datetime import datetime

print('Loading function')

# TODO - Update proxy endpoint to point to your lab database proxy endpoint
proxyEndPoint = 'productreviewproxy.proxy-c9uu3h0hyg9s.us-east-2.rds.amazonaws.com'
dbUser = "admin"
port = 3306
database = "productreview"

connection = None

# Connect to RDS using a Database Proxy
# Lambda uses IAM Role to get a connection from the Proxy
# Proxy uses credentials stored in the secrets manager to connect to the database
# With this approach, Lambda function does not have to maintain database credentials

# The application code continues to use mysql drivers to connect and run queries
# To acquire a connection using RDS Proxy, we need to provide the proxy endpoint
# when using pymysql.connect method.

def getConnection():
    # Connect to the database using proxy
    # We can optimize connection acquisition 
    # if a valid proxy connection is already available, reuse
    # otherwise, acquire a new connection
    # This can help with performance when the same lambda function
    # instance is reused for multiple requests    

    global connection
    
    try:
        print('connect with proxy')
        
        client = boto3.client('rds')

        if not connection is None and connection.open:
            print ('reuse existing connection')
            return connection
        else:
            print ('get new connection')
            
        authToken = client.generate_db_auth_token(proxyEndPoint,port,dbUser)

        connection = pymysql.connect(
                                host=proxyEndPoint,
                                user=dbUser,
                                password=authToken,
                                database=database,
                                cursorclass=pymysql.cursors.DictCursor,
                                ssl={"fake_flag_to_enable_tls":True})
            
        return connection

    except Exception as e:
        # Reset connection parameter in case of connection error
        print ('error when establishing connection to proxy')
        connection = None
        raise e

def closeConnection(connection):
    # We can close database proxy connection when no longer needed    
    # Better option is to let the database proxy to automatically close
    # idle connections based on idle connection timeout parameter
    # our code must check if proxy connection is still valid before deciding to reuse        
    if connection is not None:
        print('Close connection')
        print ('** no op** we will let Database proxy to detect idle connections and close')
        #if connection.open:
        #    connection.close()

        print('Connection closed')

# get available products
# limit = optional. limit parameter controls the page size - how many matching results
# are returned. limit is optional (default is 100) and passed by the caller
def getProducts(limit=100):    
    print("get products")
       
    response = []    

    # Database proxy connection
    connection = None
    
    try:
        # Get a database proxy connection
        connection = getConnection()

        # run query
        with connection.cursor() as cur:
            
            sql = '''SELECT product_id, product_category, product_title, sum_rating, count_rating 
            FROM productreview.product 
            ORDER BY product_id DESC
            LIMIT %s'''

            cur.execute(sql, (limit))
            for row in cur:
                response.append(row)

        return {"Items":response}

    finally:
        # Close database proxy connection
        closeConnection(connection)

def getProduct(productId):
    print(f"get product for {productId}")

    # Database proxy connection
    connection = None
    
    try:
        # Get a database proxy connection
        connection = getConnection()

        with connection.cursor() as cur:
            sql = '''SELECT product_id, product_category, product_title, sum_rating, count_rating 
            FROM productreview.product 
            WHERE product_id = %s'''

            cur.execute(sql, (productId))

            return cur.fetchone()

    finally:
        # Close database proxy connection
        closeConnection(connection)

def addProduct(productDetail):
    '''
    Template - product_id is auto generated, sum_rating, count_rating are initialized to 0
    {        
        "product_category": "computer",
        "product_title": "Ergo Mouse"
    }
    '''    
    print ('Adding new product')

    # Database proxy connection
    connection = None
    
    try:
        # Get a database proxy connection
        connection = getConnection()
        
        with connection.cursor() as cur:                 
            # product_id is configured as an auto increment column in MySQL
            # we don't need to specify a value for product_id during insert        
            sql = '''INSERT INTO productreview.product 
            (product_category, product_title, sum_rating, count_rating) 
            VALUES (%s,%s,%s,%s)'''

            cur.execute(sql, (productDetail['product_category'], 
                            productDetail['product_title'], 
                            '0', '0'))

            # product_id is auto generated by the database
            # we need to query the last inserted id for this connection
            # this will return the product id value
            sqlProductId = "SELECT LAST_INSERT_ID() as product_id"
            cur.execute(sqlProductId)
            result = cur.fetchone()
            connection.commit()

            return result['product_id']

    finally:
        # Close database proxy connection
        closeConnection(connection)

def updateProduct(productDetail):
    '''
    Template - product_id is auto generated, sum_rating, count_rating are initialized to 0
    {
        "product_id" : "uuid of the product"
        "product_category": "updated category",
        "product_title": "updated title"    
    }
    '''    
    print (f'Updating Item with product id {productDetail["product_id"]}')

    # Database proxy connection
    connection = None
    
    try:
        # Get a database proxy connection
        connection = getConnection()

        with connection.cursor() as cur:                 
            # product_id is configured as an auto increment column in MySQL
            # 
            sql = '''UPDATE productreview.product 
            SET product_category = %s,
                product_title = %s
            WHERE product_id = %s'''

            cur.execute(sql, (productDetail['product_category'], 
                            productDetail['product_title'], 
                            productDetail['product_id']))                
            connection.commit()

            return productDetail['product_id']   

    finally:
        # Close database proxy connection
        closeConnection(connection)

# delete a product
def deleteProduct(productId):
    print (f"Deleting product: {productId}")

    # Database proxy connection
    connection = None
    
    try:
        # Get a database proxy connection
        connection = getConnection()
    
        with connection.cursor() as cur:                 
            # product_id is configured as an auto increment column in MySQL
            # 
            sql = '''DELETE FROM productreview.product
            WHERE product_id = %s'''

            cur.execute(sql, (productId))                
            connection.commit()

            return productId

    finally:
        # Close database proxy connection
        closeConnection(connection)

# aggregate rating for a product
# as new reviews are added, aggregrate ratings in the product table
# So, it is easier to compute the average product rating
# sum_rating = sum_rating + new_rating
# count_rating = increment by 1
def aggregateProductRating(connection, productId, newRating):
    '''
    {
        "product_id" : "uuid of the product"
        "sum_rating": "sum_rating" + newRating,
        "count_rating": "count_rating" + 1
    }
    '''
    print (f'Updating rating for item with product id {productId}')

    with connection.cursor() as cur:                 
        sql = '''UPDATE productreview.product 
        SET sum_rating =  sum_rating + %s, 
        count_rating = count_rating + 1
        WHERE product_id = %s'''
    
        cur.execute(sql, (newRating, productId))

        # commit is done by the calling function
        # connection.commit()

        return [productId, newRating]

# add a product review
def addProductReview(productId, reviewDetail):
    '''
    Template - review ts is auto generated
    {
        "product_id" : "productId",
        "review_ts" : "timestamp"
        "review_headline": "product is great!",
        "review_body": "here are the pros/cons of this product. pros: 1...5, cons: 1..5",
        "star_rating": 4.5
    }
    '''
    reviewTs = str(datetime.utcnow().isoformat())    
    print (f'Adding Review Item with product id {productId}, and review ts {reviewTs}')

    # Database proxy connection
    connection = None
    
    try:
        # Get a database proxy connection
        connection = getConnection()
    
        with connection.cursor() as cur:                 
            
            sql = '''INSERT INTO productreview.review 
            (product_id, review_ts, review_headline, review_body, star_rating) 
            VALUES (%s,%s,%s,%s,%s)'''

            cur.execute(sql, (productId, 
                            reviewTs, 
                            reviewDetail['review_headline'],
                            reviewDetail['review_body'],
                            reviewDetail['star_rating']))

            # update product sum of rating and count of rating
            aggregateProductRating(connection, productId, reviewDetail['star_rating'])

            # commit transactions in both the product and review tables
            connection.commit()

            return [productId, reviewTs]   

    finally:
        # Close database proxy connection
        closeConnection(connection)

# return reviews for a product (specified few)
def getProductReviews(productId, limit=100, rating_gte = 0):    
    print (f"Reading reviews for product: {productId}")
    
    # Database proxy connection
    connection = None
    
    try:
        # Get a database proxy connection
        connection = getConnection()
        
        response = []        
        with connection.cursor() as cur:        
            sql = '''SELECT product_id, CAST(review_ts AS CHAR) as review_ts, review_headline, review_body, star_rating FROM productreview.review
            WHERE product_id = %s
            AND star_rating >= %s 
            ORDER BY product_id, review_ts DESC
            LIMIT %s'''

            cur.execute(sql, (productId, rating_gte, limit))
            for row in cur:
                response.append(row)

        return {"Items":response}

    finally:
        # Close database proxy connection
        closeConnection(connection)

# read a specific review for a product
def getProductReview(productId, reviewTs):
    print (f"Reading product: {productId} review: {reviewTs}")

    # Database proxy connection
    connection = None
    
    try:
        # Get a database proxy connection
        connection = getConnection()

        with connection.cursor() as cur:
            sql = '''SELECT product_id, CAST(review_ts AS CHAR) as review_ts, review_headline, review_body, star_rating
            FROM productreview.review
            WHERE product_id = %s
            AND review_ts = %s'''

            cur.execute(sql, (productId, reviewTs))
            return cur.fetchone()

    finally:
        # Close database proxy connection
        closeConnection(connection)

'''
    To collect the request details, you can inspect the following keys
    1. Chosen Route in API Gateway
        event["routeKey"]

    2. Path Parameters 
        event["pathParameters"]["id"]
            
    3. Request Body
        event["body"]

    4. Querystring Parameters
        event["queryStringParameters"]["id"]
'''
# Lambda Main Handler 
#   Examines the route key and action and invokes method to process
#   the request
def lambda_handler(event, context):    
    # print("Received event: " + json.dumps(event, indent=2))

    limit = 100 # number of matches to return in a page
    rating = 0 # filter by review rating

    try:        
        if 'routeKey' in event:
            print(f"**routeKey attribute value is:{event['routeKey']}***")
            
            # process querystring parameters            
            if 'queryStringParameters' in event:
                # check if limit is provided
                if 'limit' in event['queryStringParameters']:
                    limit = int(event['queryStringParameters']['limit'])

                    if limit <= 0:
                        limit = 100

                # check if rating is provided for filtering ratings
                # currently only get reviews uses rating
                if 'star_rating' in event['queryStringParameters']:
                    rating = float(event['queryStringParameters']['star_rating'])
                    
                    if rating <= 0:        
                        rating = 0

            # Refer to API Gateway HTTP API Configuration
            # for valid route values
            if event['routeKey'] == "GET /products":
                # return products
                return {
                    'statusCode': 200,
                    'body': json.dumps(
                        getProducts(limit), 
                        indent=4)
                    }
                    
            if event['routeKey'] == "GET /products/{productId}":
                productId = event['pathParameters']['productId']                
                # return a specific product
                return {
                    'statusCode': 200,
                    'body': json.dumps(
                        getProduct(productId),
                        indent=4)
                    }
            
            if event['routeKey'] == "POST /products":
                # add a new product
                body = json.loads(event['body'])
                productId = addProduct(body)
                return {
                    'statusCode': 200,
                    'body': json.dumps(f"POST item {productId}")
                    }

            if event['routeKey'] == "PUT /products":
                # update an existing product
                body = json.loads(event['body'])
                productId = updateProduct(body)
                return {
                    'statusCode': 200,
                    'body': json.dumps(f"PUT item {productId}")
                    }

            if event['routeKey'] == "DELETE /products/{productId}":
                # delete a product
                productId = deleteProduct(event['pathParameters']['productId'])
                return {
                    'statusCode': 200,
                    'body': json.dumps(f"DELETE item {productId}")
                    }
        
            if event['routeKey'] == "GET /products/{productId}/reviews":
                # return reviews for a specific product
                productId = event['pathParameters']['productId']
                return {
                    'statusCode': 200,
                    'body': json.dumps(
                        getProductReviews(productId,limit,rating),
                        indent=4)
                    }

            if event['routeKey'] == "GET /products/{productId}/reviews/{reviewId}":
                # return specific review for a product
                productId = event['pathParameters']['productId']
                reviewTs = event['pathParameters']['reviewId']

                return {
                    'statusCode': 200,
                    'body': json.dumps(
                        getProductReview(productId, reviewTs),
                        indent=4)
                    }

            if event['routeKey'] == "POST /products/{productId}/reviews":
                # add a new review for a product
                body = json.loads(event['body'])
                response = addProductReview(
                    event['pathParameters']['productId'], 
                    body)

                return {
                    'statusCode': 200,
                    'body': json.dumps(f"POST item {response}")
                    }

            # No matching route handler found in the code
            return {
                'statusCode': 200,
                'body': json.dumps(f"NO ACTION for routeKey is {event['routeKey']}")
                }
        else:
            print("**No routeKey attribute")
            
            return {
                'statusCode': 200,
                'body': json.dumps("Hellow from Lambda - no routeKey found")
                }
    except:
        # Get error details
        exc_type, exc_value, exc_traceback = sys.exc_info()
        
        print (exc_type, exc_value, exc_traceback)
        
        return {
            'statusCode': 500,
            'body': json.dumps(str(exc_type) + " " + str(exc_value)),
            'headers': {'Content-Type': 'application/json',}
            }