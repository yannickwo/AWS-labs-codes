import sys
import json
import pymysql
import pymysql.cursors
import boto3

print('Loading function')

# TODO: Update proxyEndPoint to point to your RDS Proxy
proxyEndPoint = 'productreviewproxy.proxy-c9uu3h0hyg9s.us-east-2.rds.amazonaws.com'
dbUser = "admin"
port = 3306
database = "productreview"

# Create product table and review table using the provided connection
# product_id is the primary key in the product table and configured as auto increment
# [product_id, review_ts] is the composite primary key in the review table
# product_id in review table is also configured as foreign key from product table
# Table are created only when they don't exist
def createTables(connection):
    productTable = '''CREATE TABLE IF NOT EXISTS `product` (
  `product_id` int(11) NOT NULL AUTO_INCREMENT,
  `product_category` varchar(100) NOT NULL,
  `product_title` varchar(255) NOT NULL,
  `sum_rating` float NOT NULL,
  `count_rating` int(11) NOT NULL,
  PRIMARY KEY (`product_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1'''

    reviewTable = '''CREATE TABLE IF NOT EXISTS `review` (
  `product_id` int(11) NOT NULL,
  `review_ts` datetime(3) NOT NULL,
  `review_headline` varchar(100) NOT NULL,
  `review_body` varchar(1024) NOT NULL,
  `star_rating` float NOT NULL,
  PRIMARY KEY (`review_ts`,`product_id`),
  KEY `product_fk_idx` (`product_id`),
  CONSTRAINT `product_fk` FOREIGN KEY (`product_id`) REFERENCES `product` (`product_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1'''

    # using the connection, create both the tables
    with connection.cursor() as cur:
        print("create product table if not exists")
        cur.execute(productTable)
        
        print("create review table if not exists")
        cur.execute(reviewTable)

# Query available products
# Limit to first 10 rows
# Use a database connection, run query and return results
def getProducts(connection):
    response = []
    with connection.cursor() as cur:
        print("cursor")
        cur.execute("SELECT product_id, product_category, product_title FROM productreview.product LIMIT 10")
        for row in cur:
            response.append(row)

    return response

# Add a few example products to the product table
# Use a database connection, insert data, commit the transaction
def insertProducts(connection):
    with connection.cursor() as cur:                
        sql = '''INSERT INTO productreview.product 
        (product_id, product_category, product_title, sum_rating, count_rating) 
        VALUES (%s,%s,%s,%s,%s)'''

        cur.execute(sql, ('1', 'computer', 'ergo keyboard', '9.0', '2'))
        cur.execute(sql, ('2', 'computer', 'ergo mouse', '5.0', '1'))
        cur.execute(sql, ('3', 'computer', 'surface laptop 4', '4.0', '1'))
        cur.execute(sql, ('4', 'computer', 'macbook air', '4.0', '1'))

    # insert/update/delete requires a commit to make the changes permanent
    connection.commit()

# Add a few example reviews to the review table
# Use a database connection, insert data, commit the transaction
def insertReviews(connection):
    with connection.cursor() as cur:                
        sql = '''INSERT INTO productreview.review 
        (product_id, review_ts, review_headline, review_body, star_rating) 
        VALUES (%s,%s,%s,%s,%s)'''

        cur.execute(sql, ('1', '2021-05-26 11:00:00.000', 'Excellent Keyboard - love it!', 'Just the type I was looking for - perfect', '5.0'))
        cur.execute(sql, ('1', '2021-05-26 11:00:05.000', 'Fantastic Keyboard','ergo design takes time to get used to it', '4.0'))
        cur.execute(sql, ('2', '2021-05-26 11:00:05.000', 'Fantastic mouse', 'Best mouse for the price - super affordable and high quality', '5.0'))
        cur.execute(sql, ('3', '2021-05-26 11:00:00.000', 'Great Laptop...but', 'not enough ports', '4.0'))
        cur.execute(sql, ('4', '2021-05-26 11:00:00.000', 'Finest laptop', 'Camera quality is awesome - easily beats my 1995 phone camera', '4.0'))

    # insert/update/delete requires a commit to make the changes permanent
    connection.commit()    

# Connect to RDS using a Database Proxy
# Lambda uses IAM Role to get a connection from the Proxy
# Proxy uses credentials stored in the secrets manager to connect to the database
# With this approach, Lambda function does not have to maintain database credentials

# The application code continues to use standard mysql drivers to connect and run queries
# To acquire a connection using RDS Proxy, we need to provide the proxy endpoint
# when using the pymysql.connect method.
def check_db_proxy_connection():
    # Connect to the database proxy
    connection = None
    
    print('start connect with proxy')
    
    try:
        client = boto3.client('rds')

        # We need to generate a token and provide it in the password parameter
        # Note this token is not the database password - it is simply used by RDS proxy to verify if lambda 
        # is allowed access to the database connection
        # RDS Proxy will verify the token and if valid, it will return a connection
        authToken = client.generate_db_auth_token(proxyEndPoint,port,dbUser)

        # Open a connection using RDS Proxy
        connection = pymysql.connect(
                                host=proxyEndPoint,
                                user=dbUser,
                                password=authToken,
                                database=database,
                                cursorclass=pymysql.cursors.DictCursor,
                                ssl={"fake_flag_to_enable_tls":True})

        print(f'Is connection open {connection.open}')
        
        print ('Create Tables')
        createTables(connection)
        
        print('Get Products')
        response = getProducts(connection)

        if len(response) == 0:
            print ('Products table is empty...Insert Products')
            insertProducts(connection)
            print ('Insert Reviews')
            insertReviews(connection)
            
        return response           

    except:
        # Get error details
        print("caught error")
        exc_type, exc_value, exc_traceback = sys.exc_info()        
        print (exc_type, exc_value, exc_traceback)
        return [exc_type, exc_value, exc_traceback]

    finally:
        if connection is not None:
            print('Close connection')
            if connection.open:
                connection.close()
            print('Connection closed')

# Handler Function - Handler is the function that is invoked when you call
# your lambda function
def lambda_handler(event, context):    
    print ("*** Database - Check RDS Proxy Connectivity ***")
    response = check_db_proxy_connection()
    print(json.dumps(response, indent=4))

    return "done"